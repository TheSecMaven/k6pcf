from .tracing import FlaskTracing  # noqa
from .tracing import FlaskTracing as FlaskTracer  # noqa, deprecated
