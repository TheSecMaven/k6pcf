Authors
=======


Lead
----

- Derrick Gilland, dgilland@gmail.com, `dgilland@github <https://github.com/dgilland>`_


Contributors
------------

- Nathan Cahill, nathan@nathancahill.com, `nathancahill@github <https://github.com/nathancahill>`_
- Klaus Sevensleeper, k7sleeper@gmail.com, `k7sleeper@github <https://github.com/k7sleeper>`_
- Bharadwaj Yarlagadda, yarlagaddabharadwaj@gmail.com, `bharadwajyarlagadda@github <https://github.com/bharadwajyarlagadda>`_
- Michael James, `urbnjamesmi1@github <https://github.com/urbnjamesmi1>`_
- Tim Griesser, tgriesser@gmail.com, `tgriesser@github <https://github.com/tgriesser>`_
- Shaun Patterson, `shaunpatterson@github <https://github.com/shaunpatterson>`_
- Brian Beck, `beck3905@github <https://github.com/beck3905>`_
- Frank Epperlein, `efenka@github <https://github.com/efenka>`_
- Joshua Wilson, `jwilson8767@github <https://github.com/jwilson8767>`_
- Eli Jose, `elijose55@github <https://github.com/elijose55>`_
