# -*- coding: utf-8 -*-
"""Project version information.
"""

__version__ = '4.8.0'
